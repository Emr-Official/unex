# unex — Pitch one-pager & landing outline

**Product:** unex (lowercase)  
**Owner:** Vanta Odds  
**Audience:** Gen Z / young adults (18+) who still care after a mess — and both opt in  
**Date:** 2026-09-21

---

## One-liner
A button-only soft-reopen channel for two people after a fight or breakup — status, mood, and intentional pings. No free typing. No secret tracking.

## Positioning (safe)
**What it is:** A calm, mutual check-in lane when texting feels too messy and blocking feels too final.  
**What it is not:** Stalking, bypassing blocks, background tracking, or “win your ex back” creep energy.

**Proof of consent:** Invite → install → Accept. Phone number alone never opens a channel.

---

## Landing page outline

### 1. Hero
- **Wordmark:** unex  
- **Headline:** Soft reopen. Both have to say yes.  
- **Subhead:** After a mess, skip the essay wars. Share status and mood, tap intentional buttons, mute or archive without drama. No free typing in the first version.  
- **Primary CTA:** Join the waitlist  
- **Secondary:** How it works (anchor)  
- **Microcopy under CTA:** 18+ · Invite + accept only · Block & Report built in  

### 2. Three features (cards)

**1. Buttons only**  
Check-in, talk, repair, or set a boundary — all taps, no free-text spiral. Rate-limited so it stays intentional.

**2. Status + mood**  
They set how they’re doing (Still sad · Working on myself · Open to talk · Need space · Moved on…). Mood can quiet the pushy taps. You see honesty without reading a novel.

**3. Mute & Archive as culture**  
Need space cools the queue. Mute stops pushes. Archive hides the thread. Clear unread without opening. Real **Block** (End pair) + Report stay buried for safety — reopen only with a new invite + accept.

*(Do not lead marketing with location / “come get me” — save for later product story once dual-consent pings ship.)*

### 3. How it works (3 steps)
1. You invite them (link/SMS).  
2. They join and **Accept** — or Decline (no channel).  
3. Soft taps + status. Mute / Archive when you need quiet.

### 4. Trust strip
- Both must opt in  
- No free typing (MVP)  
- No background “are they nearby?” radar  
- Decline / Block / Report respected  
- Not for minors · Not for unilateral pursuit  

### 5. Waitlist CTA (bottom)
- **Headline:** Be first when unex opens.  
- **Fields:** Email or phone · optional “who’s it for?” (me / us / curious)  
- **Button:** Get early access  
- **Fine print:** We’ll only message about unex. Soft vibes, no spam.

### 6. Footer
Privacy · Safety center (placeholder) · Contact · © Vanta Odds

---

## Short pitch (pasteable)

**unex** is a consensual Gen Z app for soft reopen after heartbreak or a fight. Two people both opt in (invite + accept). They share heartbreak status and mood, then communicate with buttons only — no free typing. Mute, Archive, and Clear-unread are the culture; real Block stays available for safety. Manual “come get me” pings come later, only with dual consent. Dignity over drama. Never framed as stalking or bypassing blocks.

---

## Digital-product framing (optional, Pack Builder)

| Asset | Role | Price cue |
|-------|------|-----------|
| **Waitlist landing** | Capture emails/phones before App Store | Free |
| **Brand + copy pack** (internal) | Wordmark rules, hero lines, feature cards, ASO-safe phrases | Internal |
| **Safety / store copy kit** | Block+Report language, age gate, non-goals for reviewers | Internal |
| **Later: Premium themes / sealed journal** | In-app IAP — not a Gumroad zip | App revenue |
| **Skip as Gumroad pack** | The core product is the app, not a zip template | — |

**Recommendation:** Treat unex as an **app + waitlist**, not a $17 digital download. Pack lane stays H-11 / H-13 / DLS Shorts. For unex, ship: (1) this landing, (2) waitlist form, (3) soft social teaser copy for TG/IG — Pack Builder can write those assets; engineering owns the MVP.

### Teaser blurbs (TG / IG)
- Soft reopen shouldn’t need a 40-message essay. unex — buttons only, both have to say yes. Waitlist → [LINK]  
- Status. Mood. Intentional taps. Mute when you need quiet. unex (18+)  

### ASO / store don’ts
Avoid: stalk, spy, track without consent, bypass block, find my ex, secret location.
