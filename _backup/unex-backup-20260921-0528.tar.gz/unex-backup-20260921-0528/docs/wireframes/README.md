# unex wireframes

Clickable (static) HTML phone-frame wireframes for the **unex** MVP — Gen Z soft-reopen, lowercase brand.

## How to open

1. Open the file in any modern browser (no build step, no server required):

   ```bash
   # from repo / workspace root
   open /workspace/unex/wireframes/index.html
   # or
   xdg-open /workspace/unex/wireframes/index.html
   ```

2. Or drag `index.html` into Chrome / Safari / Firefox / Edge.

3. Or serve locally if you prefer:

   ```bash
   cd /workspace/unex/wireframes && python3 -m http.server 8765
   # then visit http://localhost:8765
   ```

## What’s inside

Single self-contained file: `index.html` (CSS + Google Fonts DM Sans).

Eight phone screens in a horizontal scroll:

| # | Screen |
|---|--------|
| 1 | Onboarding / splash |
| 2 | Invite partner (phone / link) |
| 3 | Waiting for accept |
| 4 | Home (paired) — status + mood + tap deck |
| 5 | Tap confirm / sent |
| 6 | Mute & Archive controls |
| 7 | Clear unread + sender signal copy |
| 8 | Safety — End pair (Block) + Report (buried) |

## Style lock

- Background `#0c0b10`
- Accents `#c4b5fd` / `#f9a8d4`
- Soft reopen copy; both must say yes
