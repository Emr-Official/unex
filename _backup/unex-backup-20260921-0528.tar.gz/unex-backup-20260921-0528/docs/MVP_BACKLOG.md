# unex MVP Backlog

## Sprint 0 — Spec (done when PRD locked)
- [x] PRD
- [ ] Figma: 8 key screens
- [ ] Final button list (EN)
- [ ] Legal stub: ToS, Privacy, Safety

## Sprint 1 — Foundation
- [ ] App shell + nav
- [ ] Phone OTP auth
- [ ] User profile (display name, status, mood)
- [ ] Pair invite SMS/deeplink
- [ ] Accept / decline

## Sprint 2 — Core loop
- [ ] Home: paired person + status + mood
- [ ] Tap deck UI
- [ ] Send tap + rate limit
- [ ] Inbox of received taps
- [ ] Push on new tap

## Sprint 3 — Soft refuse
- [ ] Mute / unmute
- [ ] Archive / unarchive
- [ ] Clear unread + batched sender signal
- [ ] Need space cool-down queue
- [ ] End pair + Report

## Sprint 4 — Polish + pay
- [ ] Empty states + copy
- [ ] Manual ping v1 (come get me)
- [ ] Premium gate (RevenueCat)
- [ ] TestFlight / internal testing

## Pack / GTM
- [ ] Landing waitlist
- [ ] 30-sec Loom demo
- [ ] Store listing draft (no stalk language)
