# unex — Brand lock

**Name:** unex (always lowercase in logo/UI)
**Pronunciation:** "un-ex"
**One-liner:** Soft reopen for two people after a mess — buttons only.
**Taglines (pick later):**
- unmute the soft stuff
- not blocked. just muted.
- tap back when you're ready
- soft line to your ex

**Culture:** Mute & Archive first. Block is the quiet fire exit.
**Audience:** Gen Z / young millennials, mutual opt-in only.
**Avoid in marketing:** stalk, spy, find them, bypass block, force contact.
